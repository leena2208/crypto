from pages.api.api_page import apiPage
from utilities.teststatus import testStatus
import unittest, os, pytest, time
from utilities.read_data import getCSVData
from ddt import ddt, data, unpack

@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
@ddt
class JUnit5(unittest.TestCase):
    # to avoid prove not robot
    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        self.ap = apiPage(self.driver)
        self.ts = testStatus(self.driver)

    @pytest.mark.run(order=1)
    @data(*getCSVData(os.path.join(os.getcwd(),"../../testdata.csv")))
    @unpack
    def test_apidata(self, interval, instrument):
        timestamp = time.ctime()

        # This function test the response from get-candlestick api and get-trade api
        result = self.ap.verifyConsistencySuccessful(interval, instrument, timestamp)
        self.ts.markFinal("Test_apiConsistency", result, "API consistency does not match")

