from selenium import webdriver
import os, time

class webDriverFactory():

    def __init__(self, browser):
        """
        Inits webdriverfactory class
        :returns:
            None
        :param browser:
        """
        self.browser = browser

    def getDriverInstance(self):
        """
        Get webdriver instance based on the browser configuration

        :return:
            WebDriver Instance
        """
        # baseUrl = "https://api.crypto.com"

        driver_location = os.path.join(os.getcwd(), "../../../Webdrivers")
        self.timestamp = time.ctime()

        if self.browser == 'iexplorer':
            driver_location = os.path.join(driver_location, 'IEDriverServer')
            driver = webdriver.Ie(executable_path=driver_location)
        elif self.browser == 'firefox':
            driver_location = os.path.join(driver_location, 'geckodriver')
            driver = webdriver.Firefox(executable_path=driver_location)
        elif self.browser == 'chrome':
            # to avoid prove not robot
            driver_location = os.path.join(driver_location, 'chromedriver')
            opt = webdriver.ChromeOptions()
            opt.add_argument(r"user-data-dir=C:\Users\lechaudh\AppData\Local\Google\Chrome\User")
            driver = webdriver.Chrome(options=opt, executable_path=driver_location)
        else:
            driver_location = os.path.join(driver_location, 'geckodriver')
            driver = webdriver.Firefox(executable_path=driver_location)

        # Setting implicit wait time
        driver.implicitly_wait(10)

        # maximize the window
        driver.maximize_window()

        # Loading browser with App URL
        # driver.get(baseUrl)
        # will be used in future to open crypto.com page

        return driver


