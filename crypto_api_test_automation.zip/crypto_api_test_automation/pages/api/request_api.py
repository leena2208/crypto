import utilities.custome_logger as cl
import logging
from base.basepage import BasePage

class request_api(BasePage):

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    # Locators
    _baseUrl = "https://api.crypto.com/v2/public/{0}?limit=10000&sysparm_offset=0"
    _instrument_url = "instrument_name={0}"
    _interval_url = "timeframe={0}"

    def sendApiRequest(self, api=None, instrument=None, interval=None):
        if api:
            baseurl = self._baseUrl.format(api)
        if instrument:
            baseurl = baseurl + "&" + self._instrument_url.format(instrument)
        if interval:
            baseurl = baseurl + "&" + self._interval_url.format(interval)

        self.driver.get(baseurl)


    def navigateToUserSettings(self):
        userSettingsElement = self.waitForElement(locator=self._user_settings_icon,
                                      locatorType="xpath", pollFrequency=1)
        #self.elementClick(element=userSettingsElement)
        self.elementClick(locator=self._user_settings_icon,
                                      locatorType="xpath")

