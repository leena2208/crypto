import requests
from selenium import webdriver
import time
class BrowserInteractions():

    def test(self):
        baseUrl = "https://api.crypto.com/v2/public/get-trades"
        driver = webdriver.Firefox(executable_path=r"C:\Users\lechaudh\PycharmProjects\Webdrivers\geckodriver")

        # Window Maximize
        driver.maximize_window()

        # Open the Url
        driver.get(baseUrl)


ff = BrowserInteractions()
ff.test()