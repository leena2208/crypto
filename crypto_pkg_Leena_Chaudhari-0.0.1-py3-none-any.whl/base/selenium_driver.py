from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *
import utilities.custome_logger as cl
from traceback import print_stack
import time, os
import logging
from ast import literal_eval

class SeleniumDriver():
    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        self.driver = driver

    def screenShot(self, resultMessage):
        """
        Takes screenshot of current opened webpage.
        :param resultMessage:
        """
        filename = resultMessage + "." + str(round(time.time() * 1000)) + ".png"
        screenshotDir = "../screenshots/"
        relativeFileName = screenshotDir + filename
        currentDir = os.path.dirname(__file__)
        destFile = os.path.join(currentDir, relativeFileName)
        destinationDirectory = os.path.join(currentDir, screenshotDir)

        try:
            if not os.path.exists(destinationDirectory):
                os.makedirs(destinationDirectory)
            self.driver.save_screenshot(destFile)
            self.log.info('Screenshot is saved to {0} '.format(destFile))
        except:
            self.log.error("## EXCEPTION OCCURED While taking screenshot")

    def getTitle(self):
        return self.driver.title

    def getByType(self, locatorType):
        locatorType = locatorType.lower()
        if locatorType == "id":
            return By.ID
        elif locatorType == "name":
            return By.NAME
        elif locatorType == "xpath":
            return By.XPATH
        elif locatorType == "css":
            return By.CSS_SELECTOR
        elif locatorType == "class":
            return By.CLASS_NAME
        elif locatorType == "link":
            return By.LINK_TEXT
        else:
            self.log.info("Locator type " + locatorType + " not correct/supported")
        return False

    def getElement(self, locator, locatorType="id"):
        element = None
        try:
            locatorType = locatorType.lower()
            byType = self.getByType(locatorType)
            element = self.driver.find_element(byType, locator)
            self.log.info("Element found with locator - {0} and locator type - {1}".format(locator, locatorType))
        except:
            self.log.info("Element not found with locator - {0} and locator type - {1}".format(locator, locatorType))
        return element

    def clickElement(self, locator="", locatorType='id', element=None):
        """
        Click on an element or find element first and then click on it.
        Either provide locator & locator type or element.
        :param locator: XPATH
        :param locatorType: XPATH Type. id/tag/xpath/class etc
        :param element: element already found by code
        :return:
        """
        try:
            if locator:
                element = self.getElement(locator, locatorType)
            element.click()
            self.log.info('Clicked on the element with locator - {0} and locator type {1}.'.format(locator, locatorType))
        except:
            self.log.info('Clicked on the element with locator - {0} and locator type {1}.'.format(locator, locatorType))

    def sendKeys(self, data, locator="", locatorType='id', element=""):
        try:
            if locator:
                element = self.getElement(locator, locatorType)
            element.clear()
            element.send_keys(data)
            self.log.info('Sent data on the element with locator - {0} and locator type {1}.'.format(locator, locatorType))
        except:
            self.log.info('can not send data on the element with locator - {0} and locator type {1}.'.format(locator, locatorType))

    def sendKeysToIframes(self, data, locator="", locatorType='id', element="", iframe_locator=0):
        try:
            parent_handle = self.driver.current_window_handle
            self.driver.switch_to.frame(iframe_locator)
            if locator:
                element = self.getElement(locator, locatorType)
            element.clear()
            element.send_keys(data)
            self.driver.switch_to.window(parent_handle)
            self.log.info('Sent data on the element with locator - {0} and locator type {1}.'.format(locator, locatorType))
        except:
            self.log.info('can not send data on the element with iFrame {0} locator - {1} and locator type {2}.'.format(iframe_locator, locator, locatorType))


    def isElementPresent(self, locator="", locatorType="id", element=None):
        try:
            if locator:
                element = self.driver.find_element(locatorType, locator)
            if element is not None:
                self.log.info("Element found with locator - {0} and locator type {1}.".format(locator, locatorType))
                return True
            else:
                self.log.info("Element not found with locator - {0} and locator type {1}.".format(locator, locatorType))
                return False
        except:
            self.log.info("Element not found with locator - {0} and locator type {1}.".format(locator, locatorType))
            return False

    def isApiResponseCodeZero(self, code_locator="", locatorType='id'):
        try:
            if code_locator:
                element = self.driver.find_element(locatorType, code_locator)
            if element is not None:
                self.log.info("Element found with locator - {0} and locator type {1}.".format(code_locator, locatorType))
                data_dictionary = literal_eval(element.text)

                if data_dictionary['code'] == 0:
                    self.log.info(
                        "Element text for locator - {0} and locator type {1} is zero.".format(code_locator, locatorType))
                    return True, data_dictionary
                else:
                    self.log.info(
                        "Element text for locator - {0} and locator type {1} is not zero.".format(code_locator,
                                                                                                  locatorType))
                    return False
            else:
                self.log.info(
                    "Element not found with locator - {0} and locator type {1}.".format(code_locator, locatorType))
                return False
        except:
            self.log.info("Element not found with locator - {0} and locator type {1}.".format(code_locator, locatorType))
            return False

    def get_apiResponseData(self, code_locator="", locatorType='id', last_timestamp = None):
        try:
            if code_locator:

                element = self.driver.find_element(locatorType, code_locator)
                if element is not None:
                    self.log.info("Element for getting response data found with locator - {0} and locator type {1}.".format(code_locator, locatorType))
                    _data = literal_eval(element.text)
                    return _data
                else:
                    self.log.info(
                        "Element getting response data not found with locator - {0} and locator type {1}.".format(code_locator, locatorType))
                    return None
            else:
                return None
                self.log.info("Element locator for get_apiResponseData function not provided")
        except:
            self.log.info("Element not found with locator - {0} and locator type {1}.".format(code_locator, locatorType))
            return None

    def elementPresenceCheck(self, locator, byType):
        try:
            elementList = self.driver.find_elements(byType, locator)
            if len(elementList) > 0:
                self.log.info("Element Found")
                return True
            else:
                self.log.info("Element not found")
                return False
        except:
            self.log.info("Element not found")
            return False

    def waitForElement(self, locator, locatorType="id",
                       timeout=10, pollFrequency=0.5):
        element = None
        try:
            byType = self.getByType(locatorType)
            self.log.info("Waiting for maximum :: " + str(timeout) + " :: seconds for element to be clickable")
            wait = WebDriverWait(self.driver, timeout=timeout, poll_frequency=pollFrequency,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            element = wait.until(EC.element_to_be_clickable((byType, locator)))
            self.log.info("Element appeared on the web page")
        except:
            self.log.info("Element not appeared on the web page")
        return element


    def getElementList(self, locator, locatorType="id"):
        """
        NEW METHOD
        Get list of elements
        """
        element = None
        try:
            locatorType = locatorType.lower()
            byType = self.getByType(locatorType)
            element = self.driver.find_elements(byType, locator)
            self.log.info("Element list found with locator: " + locator +
                          " and  locatorType: " + locatorType)
        except:
            self.log.info("Element list not found with locator: " + locator +
                          " and  locatorType: " + locatorType)
        return element

    def getText(self, locator="", locatorType="id", element=None, info=""):
        """
        NEW METHOD
        Get 'Text' on an element
        Either provide element or a combination of locator and locatorType
        """
        try:
            if locator:  # This means if locator is not empty
                self.log.debug("In locator condition")
                element = self.getElement(locator, locatorType)
            self.log.debug("Before finding text")
            text = element.text
            self.log.debug("After finding element, size is: " + str(len(text)))
            if len(text) == 0:
                text = element.get_attribute("innerText")
            if len(text) != 0:
                self.log.info("Getting text on element :: " + info)
                self.log.info("The text is :: '" + text + "'")
                text = text.strip()
        except:
            self.log.error("Failed to get text on element " + info)
            print_stack()
            text = None
        return text

    def isElementDisplayed(self, locator="", locatorType="id", element=None):
        """
        NEW METHOD
        Check if element is displayed
        Either provide element or a combination of locator and locatorType
        """
        isDisplayed = False
        try:
            if locator:  # This means if locator is not empty
                element = self.getElement(locator, locatorType)
            if element is not None:
                isDisplayed = element.is_displayed()
                self.log.info("Element is displayed with locator: " + locator +
                              " locatorType: " + locatorType)
            else:
                self.log.info("Element not displayed with locator: " + locator +
                              " locatorType: " + locatorType)
            return isDisplayed
        except:
            print("Element not found")
            return False

    def webScroll(self, direction="up"):
        """
        Scroll up/down
        """
        if direction == "up":
            # Scroll Up
            self.driver.execute_script("window.scrollBy(0, -1000);")

        if direction == "down":
            # Scroll Down
            self.driver.execute_script("window.scrollBy(0, 1000);")

    def api_getcandlestick_data(self, duration='1m', instrument='BTC_USDT'):
        self.driver.get()