from base.selenium_driver import SeleniumDriver
import logging
import utilities.custome_logger as cl

class testStatus(SeleniumDriver):

    log = cl.customLogger(logging.INFO)

    def __init__(self, driver):
        """
        Inits checkpoint class

        """
        super(testStatus, self).__init__(driver)
        self.resultlist = list()

    def setResult(self, result, resultMessage):
        try:
            if result is not None:
                if result:
                    self.resultlist.append("PASS")
                    self.log.info("### VERIFICATION SUCCESSFUL :: + " + resultMessage)
                else:
                    self.resultlist.append("FAIL")
                    self.log.info("### VERIFICATION FAILED :: + " + resultMessage)
                    self.screenShot(resultMessage)
            else:
                self.resultlist.append("FAIL")
                self.log.error("### VERIFICATION FAILED :: + " + resultMessage)
                self.screenShot(resultMessage)
        except:
            self.resultlist.append("FAIL")
            self.log.error("### EXCEPTION OCCURRED")
            self.screenShot(resultMessage)

    def mark(self,result, resultMessage):
        """
        Mark the result of the verification point in a test case.
        :param result:
        :param resultMessage:

        """
        self.setResult(result, resultMessage)

    def markFinal(self, testName, result, resultMessage):
        """
        Mark the final result of the verification point ina test case
        This needs to be collected at least once in a test case.
        This should be final test status of the test case.

        """
        self.setResult(result, resultMessage)

        if "FAIL" in self.resultlist:
            self.log.error(testName + " ## Test Failed")
            self.resultlist.clear()
            assert True == False
        else:
            self.log.info(testName + " ## Test Successful")
            self.resultlist.clear()
            assert True == True


