import time
import traceback
import random, string
import utilities.custome_logger as cl
import logging

class Util(object):
    log = cl.customLogger(logging.INFO)

    def sleep(self, sec, info=""):
        """
        Put the program to wait for the specified amount of time
        :param sec:
        :param info:
        :return:
        """
        if info is not None:
            self.log.info("Wait :: '" + str(sec) + "'seconds for " + info)
        try:
            time.sleep(sec)
        except InterruptedError:
            traceback.print_stack()

    def getAlphaNumeric(self, length, type='letters'):
        """
        Get random string of characters
        :param length: Length of string, number of characters, string should have
        :param type: Type of characters string should have. default is letters
        provide lower/upper/digits for different types

        :return:

        """
        alpha_num = ''
        if type == 'lower':
            case = string.ascii_lowercase
        elif type == 'upper':
            case = string.ascii_lowercase
        elif type == 'digits':
            case = string.digits
        elif type == 'mix':
            case = string.ascii_letters + string.digits
        else:
            case = string.ascii_letters

        return alpha_num.join(random.choice(case) for i in range(length))

    def getUniqueName(self, charCount=10):
        """
        Get a unique name
        :param charCount:
        :return:
        """
        return self.getAlphaNumeric(charCount, 'lower')

    def getUniqueNameList(self, listSize=5, itemLength=None):
        """
        Get list of valid email ids
        :param listSize: Number of name ids. Default is 5 names in a list.
        :param itemLength: it should be a list contain number of items equal
        to the listSize. This determines the length at the each
        item in the list [1, 2, 3,4, 5]
        :return:
        """
        nameList = list()

        for i in range(0, listSize):
            nameList.append(self.getUniqueName(itemLength[i]))
        return nameList

    def verifyTextContains(self, actualText, expectedText):
        """
        Verify actual text contains is equal to expected text contains

        :param actualText:

        :param expectedText:

        :return:
            Boolean value
        """
        self.log.info("Actual text from application web UI --> :: " + actualText)
        self.log.info("expected text from application web UI --> :: " + expectedText)

        if expectedText.lower() in actualText.lower():
            self.log.info("### VERIFICATION CONTAINS!!!")
            return True
        else:
            self.log.info("### VERIFICATION DOES NOT CONTAIN!!!")
            return False

    def verifyTextMatch(self, actualText, expectedText):
        """
        Verify actual text contains is equal to expected text contains

        :param actualText:

        :param expectedText:

        :return:
            Boolean value
        """
        self.log.info("Actual text from application web UI --> :: " + actualText)
        self.log.info("expected text from application web UI --> :: " + expectedText)

        if expectedText.lower() == actualText.lower():
            self.log.info("### VERIFICATION CONTAINS!!!")
            return True
        else:
            self.log.info("### VERIFICATION DOES NOT CONTAIN!!!")
            return False

    def verifyListMatch(self, expectedList, actualList):
        """
        Verify two list matches

        Parameters:
            expectedList: Expected List
            actualList: Actual List
        """
        return set(expectedList) == set(actualList)

    def verifyListContains(self, expectedList, actualList):
        """
        Verify actual list contains elements of expected list

        Parameters:
            expectedList: Expected List
            actualList: Actual List
        """
        length = len(expectedList)
        for i in range(0, length):
            if expectedList[i] not in actualList:
                return False
        else:
            return True
