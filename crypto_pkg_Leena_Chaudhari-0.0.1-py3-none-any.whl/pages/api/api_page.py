from datetime import datetime
import utilities.custome_logger as cl
from pages.api.request_api import request_api
import logging
import time
from base.basepage import BasePage

class apiPage(BasePage):
    log = cl.customLogger(logging.DEBUG)


    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.req = request_api(driver)


    # Locators
    _reponse_code = "//pre[contains(text(),'code')]"


    def send_getTrade_req(self):
        self.req.sendApiRequest(api='get-trades')

    def get_apidata_data(self):
        data = self.get_apiResponseData(code_locator=self._reponse_code, locatorType='xpath')
        return data

    def send_candlestick_req(self, interval="", instrument=""):
        self.req.sendApiRequest(api='get-candlestick',interval=interval, instrument=instrument)

    def verifyGetCandlestickSuccessful(self):
        result = self.isApiResponseCodeZero(code_locator=self._reponse_code, locatorType='xpath')
        return result,

    def verifyGetTradesSuccessful(self):
        result = self.isApiResponseCodeZero(code_locator=self._reponse_code, locatorType='xpath')
        return result

    def verifyConsistencySuccessful(self, interval, instrument, timestamp):
        self.req.sendApiRequest(api='get-trades', instrument=instrument)
        trade_data = self.get_apiResponseData(code_locator=self._reponse_code, locatorType='xpath')

        self.req.sendApiRequest(api='get-candlestick', interval=interval, instrument=instrument)
        candle_data = self.get_apiResponseData(code_locator=self._reponse_code, locatorType='xpath')

        result = self.verifyConsistency(interval, instrument, trade_data, candle_data, timestamp)

        self.write_test_result(interval, instrument, result)

        return result

    def write_test_result(self, interval, instrument, result):

        fp = open('report/Final_test_report_' + '.csv', 'a+')
        fp.write("%s,%s,%s\n" % (interval, instrument, result))
        fp.close()

    def calculate_candle_duration(self, interval):
        candle_duration = interval.replace('m', '*60*1000')
        candle_duration = candle_duration.replace('h', '*60*60*1000')
        candle_duration = candle_duration.replace('D', '*24*60*60*1000')
        candle_duration = candle_duration.replace('M', '*30*24*60*60*1000')

        try:
            candle_duration = eval(candle_duration)
            return candle_duration
        except:
            self.log.info('Invalid Candle interval')
            return None

    def write_to_test_report(self, curr_candle, interval, instrument, timestamp):
        fp = open('report/result_data_' + instrument + '_' + interval + '_' + timestamp + '.csv', 'a+')
        fp.write("curr candle opening time, curr candle closing time, High, Low, Open, Close\n")
        candle_open_time = curr_candle['t'] - self.calculate_candle_duration(interval)
        candle_open_time = time.ctime(int(candle_open_time / 1000))
        candle_close_time = time.ctime(int(curr_candle['t']/1000))

        fp.write(
            "%s,%s,%s,%s,%s,%s\n" % (candle_open_time, candle_close_time, curr_candle['h'],
                                     curr_candle['l'], curr_candle['o'], curr_candle['c']))

        fp.write("%s,%s,\n" % ('Candle Low price match', curr_candle['Low_trade_price_match']))
        fp.write("%s,%s,\n" % ('Candle High price match', curr_candle['High_trade_price_match']))
        fp.write("%s,%s,\n" % ('Candle close price match', curr_candle['close_trade_price_match']))
        fp.write("%s,%s,\n" % ('Candle close price match', curr_candle['open_trade_price_match']))
        fp.close()

    def verifyConsistency(self, interval, instrument, trade_data, candle_data, timestamp):
        test_success_flag = True
        curr_candle_duration = self.calculate_candle_duration(interval)
        if not trade_data or not candle_data:
            test_success_flag = False
            self.log.info('Data obtained from API is Null')
            return test_success_flag

        fp = open('report/debug_files/trade_complete_data_' + instrument + '_' + interval + '.csv', 'w+')

        for each_concerned_data in trade_data['result']['data']:
            fp.write("%s,%s,%s,%s\n" % (each_concerned_data['t'],
                                     time.ctime(int(each_concerned_data['t'] / 1000)),
                                     each_concerned_data['p'], each_concerned_data['q']))
        fp.close()

        if not curr_candle_duration:
            return False

        curr_candle_dictionary = candle_data['result']['data']
        # curr_candle_dictionary.sort(reverse=True)

        for current_candle in curr_candle_dictionary:
            curr_candle_closing_time = current_candle['t']
            curr_candle_opening_time = current_candle['t'] - curr_candle_duration

            open_trade = dict()
            close_trade = dict()
            trade_timestamp = list()
            trade_data_related = list()
            price_value = []

            _timestamp = timestamp.replace(' ', '_')
            _timestamp = _timestamp.replace(':', '_')

            self.log.info('candle open time : ' + instrument + ' ' + time.ctime(int(curr_candle_opening_time/1000)))
            self.log.info('candle close time : ' + instrument + ' ' + time.ctime(int(curr_candle_closing_time/1000)))

            for each_trade in trade_data['result']['data']:
                # self.log.info('curr_trade_time : ' + str(each_trade['t']))
                if each_trade['t'] >= curr_candle_opening_time and each_trade['t'] <= curr_candle_closing_time:
                    trade_timestamp.insert(len(trade_timestamp)-1, each_trade['t'])
                    trade_data_related.insert(len(trade_data_related)-1, each_trade)
                    price_value.insert(len(price_value), each_trade['p'])

            if trade_timestamp == []:
                self.log.info('******* Candle values can not be validated as related trades are not found! ********')
                current_candle['close_trade_price_match'] = 'NA'
                current_candle['open_trade_price_match'] = 'NA'
                current_candle['High_trade_price_match'] = 'NA'
                current_candle['Low_trade_price_match'] = 'NA'
                test_success_flag = False
                self.write_to_test_report(current_candle, interval, instrument, _timestamp)
                continue

            trade_timestamp.sort(reverse=False)
            test_value = time.ctime(int(curr_candle_closing_time/1000))
            test_value = test_value.replace(' ', '_')
            test_value = test_value.replace(':', '_')

            fp = open('report/debug_files/Candle_data_' + instrument + '_' + interval + test_value + '.csv', 'w+')
            fp.write("curr candle opening time, curr candle closing time, High, Low, Open, Close\n")
            fp.write("%s,%s,%s,%s,%s,%s\n" % (time.ctime(int(curr_candle_opening_time / 1000)),
                                              time.ctime(int(curr_candle_closing_time / 1000)),
                                              current_candle['h'], current_candle['l'],
                                              current_candle['o'], current_candle['c']))
            fp.write("%s,%s,%s,%s,%s,%s,%s\n" % (curr_candle_opening_time,
                                              curr_candle_closing_time,
                                              current_candle['h'], current_candle['l'],
                                              current_candle['o'], current_candle['c'], current_candle['v']))

            for each_concerned_data in trade_data_related:
                fp.write("%s,%s,%s,%s\n" % (each_concerned_data['t'],
                                   time.ctime(int(each_concerned_data['t']/1000)),
                                   each_concerned_data['p'], each_concerned_data['q']))
            fp.close()


            for each_trade in trade_data_related:
                if each_trade['t'] == trade_timestamp[0]:
                    open_trade = each_trade
                if each_trade['t'] == trade_timestamp[len(trade_timestamp)-1]:
                    close_trade = each_trade
            price_value.sort()
            self.log.info('My candle open value from trade is : ' + str(open_trade['p']))
            self.log.info('My candle open value in candle  is : ' + str(current_candle['o']))

            if open_trade['p'] != current_candle['o']:
                self.log.info('Open trade value for candle does not match with open value from trades.')
                current_candle['open_trade_price_match'] = False
                test_success_flag = False
            else:
                self.log.info('Open trade value for candle match with open value from trades.')
                current_candle['open_trade_price_match'] = True

            self.log.info('My candle close value from trade is : ' + str(close_trade['p']))
            self.log.info('My candle close value in candle is : ' + str(current_candle['c']))

            if close_trade['p'] != current_candle['c']:
                self.log.info('close trade value for candle does not match with open value from trades.')
                current_candle['close_trade_price_match'] = False
                test_success_flag = False
            else:
                self.log.info('Close trade value for candle match with open value from trades.')
                current_candle['close_trade_price_match'] = True


            self.log.info('High value from trade: ' + str(price_value[len(price_value) - 1]))
            self.log.info('My High value in candle : ' + str(current_candle['h']))

            if price_value[len(price_value) - 1]!= current_candle['h']:
                self.log.info('High trade value for candle does not match with open value from trades.')
                current_candle['High_trade_price_match'] = False
                test_success_flag = False
            else:
                self.log.info('High trade value for candle match with open value from trades.')
                current_candle['High_trade_price_match'] = True

            self.log.info('Low value from trade: ' + str(price_value[0]))
            self.log.info('My Low value in candle : ' + str(current_candle['l']))

            if price_value[0] != current_candle['l']:
                self.log.info('Low trade value for candle does not match with open value from trades.')
                current_candle['Low_trade_price_match'] = False
                test_success_flag = False
            else:
                self.log.info('Low trade value for candle match with open value from trades.')
                current_candle['Low_trade_price_match'] = True

            self.write_to_test_report(current_candle, interval, instrument, _timestamp)

        return test_success_flag

